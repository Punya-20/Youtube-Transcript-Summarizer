from flask import Flask, request, render_template_string
from youtube_transcript_api import YouTubeTranscriptApi
import re
import logging
from transformers import pipeline

app = Flask(__name__)

# Initialize the summarization pipeline with BART
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

def extract_video_id(url):
    """
    Extracts video ID from a YouTube URL.
    """
    youtube_regex = (
        r'(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\n\s]{11})'
    )
    match = re.search(youtube_regex, url)
    return match.group(1) if match else None

def fetch_transcript(video_id):
    """
    Fetches the transcript of a YouTube video using its ID.
    """
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        return ' '.join([entry['text'] for entry in transcript])
    except Exception as e:
        return str(e)

# Set up logging
logging.basicConfig(level=logging.ERROR)

def summarize_text(text, chunk_size=1024, max_length=300, min_length=30):
    """
    Summarizes text of any length by chunking it and summarizing each chunk.
    
    Parameters:
    - text (str): The text to summarize.
    - chunk_size (int): The maximum length of each chunk (in tokens).
    - max_length (int): The maximum length of the summary for each chunk (in tokens).
    - min_length (int): The minimum length of the summary for each chunk (in tokens).

    Returns:
    - str: The combined summary of the text.
    """
    tokens = text.split()
    if len(tokens) == 0:
        return "No content to summarize."

    # Create chunks
    chunks = [tokens[i:i + chunk_size] for i in range(0, len(tokens), chunk_size)]
    
    summaries = []
    for chunk in chunks:
        if not chunk:
            continue
        chunk_text = ' '.join(chunk).strip()
        if len(chunk_text) == 0:
            continue
        try:
            summary = summarizer(chunk_text, max_length=max_length, min_length=min_length, do_sample=False)
            summaries.append(summary[0]['summary_text'])
        except IndexError:
            logging.error("Index out of range while summarizing chunk.", exc_info=True)
            summaries.append("Summary:")
        except Exception as e:
            logging.error(f"Summary error: {str(e)}", exc_info=True)
            summaries.append(f"Summary error: {str(e)}")
    
    combined_summary = " ".join(summaries).strip()
    
    return combined_summary

# HTML template for input and output
HTML_TEMPLATE = '''
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>YouTube Transcript Summarizer</title>
  </head>
  <body>
    <h1>YouTube Transcript Summarizer</h1>
    <form method="post">
      <input type="text" name="url" placeholder="Enter YouTube video URL" value="{{ url }}" size="50"><br><br>
      <input type="submit" value="Summarize">
    </form>
    {% if summary %}
      <h2>Summary:</h2>
      <p>{{ summary }}</p>
    {% elif error %}
      <h2>Error:</h2>
      <p>{{ error }}</p>
    {% endif %}
  </body>
</html>
'''

@app.route('/', methods=['GET', 'POST'])
def index():
    summary = None
    error = None
    url = request.form.get('url', '')
    
    if request.method == 'POST' and url:
        video_id = extract_video_id(url)
        if video_id:
            transcript = fetch_transcript(video_id)
            if transcript:
                summary = summarize_text(transcript)
            else:
                error = "Unable to fetch transcript."
        else:
            error = "Invalid YouTube URL."
    
    return render_template_string(HTML_TEMPLATE, summary=summary, error=error, url=url)

if __name__ == '__main__':
    app.run(debug=True)
