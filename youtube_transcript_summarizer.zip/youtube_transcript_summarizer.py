from transformers import pipeline

def summarize_text(text, chunk_size=1024,max_length=10000,min_length=1):
    """
    Summarizes text of any length by chunking it and summarizing each chunk.
    
    Parameters:
    - text (str): The text to summarize.
    - chunk_size (int): The maximum length of each chunk (in tokens).
    - max_length (int): The maximum length of the summary for each chunk (in tokens).
    - min_length (int): The minimum length of the summary for each chunk (in tokens).

    Returns:
    - str: The combined summary of the text.
    """
    # Initialize the summarization pipeline
    summarizer = pipeline("summarization", model="sshleifer/distilbart-cnn-12-6")

    # Tokenize the input text into manageable chunks
    tokens = text.split()
    chunks = [tokens[i:i + chunk_size] for i in range(0, len(tokens), chunk_size)]
    
    summaries = []
    for chunk in chunks:
        chunk_text = ' '.join(chunk)
        summary = summarizer(chunk_text, max_length=max_length, min_length=min_length, do_sample=False)
        summaries.append(summary[0]['summary_text'])
    
    # Combine all chunk summaries into one summary
    combined_summary = " ".join(summaries)
    
    return combined_summary

# Example usage
text = """Your long transcript or any large text data goes here..."""
summary = summarize_text(text)
print(summary)
